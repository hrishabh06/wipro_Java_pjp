abstract class GeneralBank{
	abstract double getSavingInterestRate();
	abstract double getFixedDepositInterestRate();
}

class ICICIBank extends GeneralBank{
	double saving, fixed;
	double getSavingInterestRate(){
		saving=4.0;
		return saving;
	} 
	double getFixedDepositInterestRate(){
		fixed=8.5;
		return fixed;
	}
}

class KotMBank extends GeneralBank{
	double saving, fixed;
	double getSavingInterestRate(){
		saving=6.0;
		return saving;
	} 
	double getFixedDepositInterestRate(){
		fixed=9.0;
		return fixed;
	}
}

public class Test1{
	public static void main(String ar[]){
		ICICIBank i=new ICICIBank();
		System.out.println("Saving Interest Rate of ICICI : "+i.getSavingInterestRate());
		System.out.println("Fixed Interest Rate of ICICI : "+i.getFixedDepositInterestRate());
		
		KotMBank k=new KotMBank();
		System.out.println("Saving Interest Rate of KotM : "+k.getSavingInterestRate());
		System.out.println("Fixed Interest Rate of KotM : "+k.getFixedDepositInterestRate());
		
		GeneralBank g=new KotMBank();
		System.out.println("Saving Interest Rate of KotM : "+g.getSavingInterestRate());
		System.out.println("Fixed Interest Rate of KotM : "+g.getFixedDepositInterestRate());
		
		GeneralBank g1=new ICICIBank();
		System.out.println("Saving Interest Rate of ICICI : "+g1.getSavingInterestRate());
		System.out.println("Fixed Interest Rate of ICICI : "+g1.getFixedDepositInterestRate());
	}
}