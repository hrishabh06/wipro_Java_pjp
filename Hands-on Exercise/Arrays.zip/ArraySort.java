import java.util.*;
class ArraySort{
	public static void main(String ar[]){
		int n,i,k;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int a[] = new int[n];
		for( i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		Arrays.sort(a);
		for( i=0;i<n;i++){
			System.out.print(a[i]+"\t");
		}
	}	
}		