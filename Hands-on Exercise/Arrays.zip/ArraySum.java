import java.util.*;
class ArraySum{
	public static void main(String ar[]){
		int n,i,s=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int a[] = new int[n];
		for( i=0;i<n;i++){
			a[i]=sc.nextInt();
			s=s+a[i];
		}
		System.out.println("Sum = " + s);
		System.out.println("Average = " + s/n);
	}
}