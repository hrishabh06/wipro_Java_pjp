import java.util.*;

class ArraySum2{
	public static void main(String ar[]){
		int n,i,s=0,min=9999,max=0;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int a[] = new int[n];
		for( i=0;i<n;i++){
			a[i]=sc.nextInt();
		}
		for(i=0;i<n;i++){
			if(min>a[i])
				min=a[i];
			if(max<a[i])
				max=a[i];
		}
		System.out.println("MIN = " + min);
		System.out.println("MAX = " + max);
	}
	
}