import java.util.*;
class MaximumElementIn2dArray{
	public static void main(String args[]){
		int r,c,i,j,t=0;
		
		int a[][] = new int[3][3];
		for( i=0;i<3;i++){
			for(j=0;j<3;j++){
				a[i][j]=Integer.parseInt(args[t++]);
			}
		}
		for( i=0;i<3;i++){
			for(j=0;j<3;j++){
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		int max=0;
		for( i=0;i<3;i++){
			for(j=0;j<3;j++){
				if(max<a[i][j])
					max=a[i][j];
			}
		}
		System.out.println("Maximum Element is = " + max);
	}
}