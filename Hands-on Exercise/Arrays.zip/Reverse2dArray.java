import java.util.*;
class Reverse2dArray{
	public static void main(String ar[]){
		int r,c,i,j,s=0;
		Scanner sc=new Scanner(System.in);
		r=sc.nextInt();
		c=sc.nextInt();
		int a[][] = new int[r][c];
		for( i=0;i<r;i++){
			for(j=0;j<c;j++){
				a[i][j]=sc.nextInt();
			}
		}
		for( i=0;i<r;i++){
			for(j=0;j<c;j++){
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		for(i=(r-1); i>=0;i--){
			for(j=(c-1); j>=0;j--){
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}
}