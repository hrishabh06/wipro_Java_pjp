import java.util.*;
import java .io.*; 
class SumExcludingRange{ 
	static void sumExcluding(int li[], int a, int b) 
	{ 
		int sum = 0; 
		boolean add = true; 
		for (int i = 0; 
				i < li.length; i++) 
		{ 
			if (li[i] != a && 
				add == true) 
				sum = sum + li[i]; 
			else if (li[i] == a) 
				add = false; 
			else if( li[i] == b) 
				add = true; 
		} 
		System.out.print(sum); 
	} 

	public static void main(String[] args) 
	{ 
		int n,i,k;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		int lis[] = new int[n];
		for( i=0;i<n;i++){
			lis[i]=sc.nextInt();
		} 
		int a,b;
		//Enter Range
		a=sc.nextInt();
		b=sc.nextInt();
		
		sumExcluding(lis, a, b); 
	} 
} 

