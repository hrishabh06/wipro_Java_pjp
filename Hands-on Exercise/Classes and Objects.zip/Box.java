import java.util.*;
class Box{
	static double l,b,h;
	Box(double l,double b,double h){
		this.l=l;
		this.b=b;
		this.h=h;
	}
	public double Volume(double l,double b,double h){
		return (l*b*h);
	}
	public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		l=sc.nextDouble();
		b=sc.nextDouble();
		h=sc.nextDouble();
		Box x=new Box(l,b,h);
		double v=x.Volume(l,b,h);
		System.out.println(v);
	}
}