import java.util.*;
class Calculator{
	static int powerInt(int num1,int num2){
		return((int)Math.pow(num1,num2));
	}
	static double powerDouble(double num1,double num2){
		return(Math.pow(num1,num2));
	}
	public static void main(String ar[]){
		int a,b;
		double c,d;
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextDouble();
		d=sc.nextDouble();
		System.out.println("Power of INT : " + powerInt(a,b));
		System.out.println("Power of DOUBLE : " + powerDouble(c,d));
	}
}