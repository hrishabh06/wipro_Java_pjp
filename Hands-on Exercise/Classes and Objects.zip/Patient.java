import java.util.*;
class Patient{
	double computeBMI(double weight, double height){
		return(weight+(height*height));
	}
	public static void main(String ar[]){
		String clss="Patient";
		String pname;
		double weight,height;
		Scanner sc=new Scanner(System.in);
		pname=sc.nextLine();
		weight=sc.nextDouble();
		height=sc.nextDouble();
		Patient p=new Patient();
		System.out.println("CLASS : "+clss);
		System.out.println("Patient Name " + pname);
		System.out.println("BMI of Patient : " + p.computeBMI(weight,height));
	}
}