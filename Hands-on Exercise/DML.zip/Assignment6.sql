INSERT ALL INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary) INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary) INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary) INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary) INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary) INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary) INTO my_employee(employee_id,first_name,last_name,department_id,salary) VALUES (&employee_id,'&first_name'
,'&last_name',&department_id,&salary)
SELECT 1 FROM DUAL;