class Book{
	String name,author;
	double price;
	int qtyInStock;
	Book(String name,String author,double price,int qtyInStock){
		this.name=name;
		this.author=author;
		this.price=price;
		this.qtyInStock=qtyInStock;
	}
	void setName(String name){
		this.name=name;
	}
	void setAuthor(String author){
		this.author=author;
	}
	void setPrice(double price){
		this.price=price;
	}
	void setQtyInStock(int qtyInStock){
		this.qtyInStock=qtyInStock;
	}
	
	String getName(){
		return this.name;
	}
	String getAuthor(){
		return this.author;
	}
	double getPrice(){
		return this.price;
	}
	int getQtyInStock(){
		return this.qtyInStock;
	}
}

public class Author{
	String name,email;
	char gender;
	Author(String name,String email,char gender){
		this.name=name;
		this.email=email;
		this.gender=gender;
	}
	public static void main(String ar[]){
		Book b=new Book("Physics","H.C.Verma", 932.12, 8);
		System.out.println("Book Name : " + b.getName());
		System.out.println("Author Name : " + b.getAuthor());
		System.out.println("Book Price : " + b.getPrice());
		System.out.println("Book Quantity : " + b.getQtyInStock());
	}
}