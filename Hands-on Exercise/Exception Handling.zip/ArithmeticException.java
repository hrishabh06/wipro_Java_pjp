import java.util.*;
import java.lang.ArithmeticException;
import java.io.*;
class ArithmeticException{
		public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		AritnmeticExceptionExample ae=new AritnmeticExceptionExample();
		int a=sc.nextInt();
		int b=sc.nextInt();
		try{		
				ae.division(a,b);
				throw new ArithmeticException();
		}
		catch(ArithmeticException e){
			System.out.println(e);
		}
	}
	
	double division(double a,double b){
		return(a/b);
	}
}