import java.util.*;
import java.lang.ArithmeticException;
import java.io.*;
class ArithmeticExceptionExample{
		public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		AritnmeticExceptionExample ae=new AritnmeticExceptionExample();
		int a=sc.nextInt();
		int b=sc.nextInt();
		double r;
		try{		
				r=division(a,b);
		}
		catch(ArithmeticException e){
			System.out.println(e);
		}
	}
	
	static double division(double a,double b){
		if(b==0)
			throw new ArithmeticException();
		return (a/b);
	}
}