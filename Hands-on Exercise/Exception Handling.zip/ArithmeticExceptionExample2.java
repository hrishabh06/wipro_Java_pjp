import java.util.*;
import java.lang.ArithmeticException;
import java.io.*;
class ArithmeticExceptionExample2{
		public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		AritnmeticExceptionExample ae=new AritnmeticExceptionExample();
		int a=sc.nextInt();
		int b=sc.nextInt();
		double r;
		try{		
				r=division(a,b);
				System.out.println(r);
		}
		catch(ArithmeticException e){
			System.out.println(e);
		}
		finally{
			System.out.println("Inside Finally Block");
		}
	}
	
	static double division(double a,double b){
		if(b==0)
			throw new ArithmeticException();
		return (a/b);
	}
}