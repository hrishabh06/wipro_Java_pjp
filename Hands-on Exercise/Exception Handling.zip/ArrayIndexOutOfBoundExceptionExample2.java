import java.util.*;
import java.io.*;
class ArrayIndexOutOfBoundExceptionExample2{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] ar=new int[n];
		for(int i=0;i<n;i++){
			ar[i]=sc.nextInt();
		}
		int k=sc.nextInt();
		try{
			if(k>n)
				throw new ArrayIndexOutOfBoundsException();
			else
			System.out.println(ar[k-1]);
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
		}
		catch(Exception g){
			System.out.println(g);
		}
	}
}