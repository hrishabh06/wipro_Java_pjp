import java.util.*;
import java.io.*;
class MathOperation{
	public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		int[] a=new int[5];
		int i,s=0;
		try{
			for(i=0;i<5;i++){
				a[i]=Integer.parseInt(ar[i]);
				if(a[i]<0)
					throw new NumberFormatException();
				else{
					s=s+a[i];
				}
			}
			System.out.println("SUM : "+s);
			System.out.println("AVERAGE : " +(double)s/5);
		}
		catch(NumberFormatException e){
			System.out.println("Entered input is not a valid format for an Integer ");
		}
	}
}