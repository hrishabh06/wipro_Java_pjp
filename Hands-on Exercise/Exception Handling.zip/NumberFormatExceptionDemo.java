import java.util.Scanner;
import java.io.*;
class NegativeValuesException extends Exception{
	public NegativeValuesException(String str){
	System.out.println(str);
	}
}
class ValuesOutOfRangeException extends Exception{
	public ValuesOutOfRangeException(String str){
	System.out.println(str);
	}
}
public class NumberFormatExceptionDemo{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);		
			String name = "";
			int subA = 0;
			int subB = 0;
			int subC = 0;
			name=sc.nextLine();
			subA=sc.nextInt();
			subB=sc.nextInt();
			subC=sc.nextInt();
			try{
				if (subA<0) 
					throw new NegativeValuesException("Less than Zero");
				if (subA>100)
					throw new ValuesOutOfRangeException("Greater than 100");
				if (subB<0)
					throw new NegativeValuesException("Less than Zero");
				if (subB>100)
					throw new ValuesOutOfRangeException("Greater than 100");
				if (subC<0)
					throw new NegativeValuesException("Less than Zero");
				if (subC>100)
					throw new ValuesOutOfRangeException("Greater than 100");
			}

			catch(NegativeValuesException e){
				System.out.println(e);
			}
			catch(ValuesOutOfRangeException e){
				System.out.println(e);
			}
			
			System.out.println("Name: " + name);
			System.out.println("Marks of subject A: " + subA);
			System.out.println("Marks of subject B: " + subB);
			System.out.println("Marks of subject C: " + subC);
		
	}
}