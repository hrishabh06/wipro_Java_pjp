import java.util.*;
import java.io.*;
class Sample{
	public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		try{
			int n=Integer.parseInt(s);
			if(n<0)
				throw new NumberFormatException();
			else
			System.out.println(Math.pow((Integer.parseInt(s)),2));
		}
		catch(NumberFormatException e){
			System.out.println("Entered input is not a valid format for an Integer ");
		}
	}
}