import java.util.*;
class AlphabetOrDigit{
	public static void main(String ar[]){
		char i;
		Scanner sc = new Scanner(System.in);
		i = sc.next().charAt(0);
		if ((i >= 65 && i <= 90) || (i >= 97 && i <= 122)) 
			System.out.print(" Alphabet "); 
 
		else if (i >= 48 && i <= 57) 
			System.out.print(" Digit "); 
		
		else
			System.out.print(" Special Character"); 
	}
}