class AlphabeticalOrder
{
    public static void main (String[] args)
    {
        char item='a';
        char item2='b';
        if (item>item2)
            System.out.println(item2+" , "+item);
       
        else
            System.out.println(item+" , "+item2);
    }
}