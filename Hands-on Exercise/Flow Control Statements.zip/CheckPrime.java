import java.util.*;
class CheckPrime{
	public static void main(String ar[]){
		int i,j,flag=0;
		Scanner sc=new Scanner(System.in);
		i= sc.nextInt();
		for(j=2;j<i/2;j++){
			if(i%j==0)
					flag=1;
		}
		if(flag==0)
			System.out.print( i + " is a prime number");
		else
			System.out.print( i + " is not a prime number");
	}
}