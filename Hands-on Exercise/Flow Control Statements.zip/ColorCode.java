import java.util.*;
class ColorCode{
	public static void main(String ar[]){
		char i;
		Scanner sc = new Scanner(System.in);
		i = sc.next().charAt(0);
		switch(i)
		{
			case 'R' : System.out.print("Red"); 
				break;
			case 'B' : System.out.print("Blue"); 
				break;
			case 'G' : System.out.print("Green"); 
				break;
			case 'O' : System.out.print("Orange"); 
				break;
			case 'Y' : System.out.print("Yellow"); 
				break;
			case 'W' : System.out.print("White"); 
				break;
			default : System.out.println("Invalid Color");
			break;
		}
	}
}