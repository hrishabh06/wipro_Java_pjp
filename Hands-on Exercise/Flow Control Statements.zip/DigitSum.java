import java.util.*;
class DigitSum{
	public static void main(String ar[]){
		int i,r,s=0;
		Scanner sc=new Scanner(System.in);
		i= sc.nextInt();
		while(i>0){
			r=i%10;
			s+=r;
			i=i/10;
		}
		System.out.print(s);
	}
}