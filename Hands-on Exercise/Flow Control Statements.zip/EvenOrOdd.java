import java.util.*;
class EvenOrOdd{
	public static void main(String ar[]){
		int i;
		Scanner sc=new Scanner(System.in);
		i=sc.nextInt();
		if(i%2==0)
			System.out.println(i + " is an EVEN Integer");
		else
			System.out.println(i + " is an ODD integer");
	}
}