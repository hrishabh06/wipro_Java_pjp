import java.util.*;
class Example10{
	public static void main(String ar[]){
		int i;
		for(i=0;i<10;i++){
			System.out.print((i+1) + "\t");
		}
	}
}