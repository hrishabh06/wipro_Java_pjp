import java.util.*;
class Example11{
	public static void main(String ar[]){
		int i;
		for(i=23;i<57;i++){
			if(i%2==0)
				System.out.print( i + "\t");
		}
	}
}