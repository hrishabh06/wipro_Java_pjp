import java.util.*;
class Example19{
	public static void main(String ar[]){
		int i,r=5,s=5;
		while(true){
			if((s%2==0) && (s%3==0) && (s%5==0)){
				System.out.println(s);
				r--;
			}
			if(r==0)
				break;
			s++;
		}
	}
}