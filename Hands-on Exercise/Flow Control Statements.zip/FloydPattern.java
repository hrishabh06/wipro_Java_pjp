import java.util.*;
class FloydPattern{
	public static void main(String ar[]){
		int i,j,flag=0;
		Scanner sc=new Scanner(System.in);
		i= sc.nextInt();
		for(j=0;j<i;j++){
			for(int k=0;k<=j;k++)
				System.out.print("*");
			System.out.println();
		}
	}
}