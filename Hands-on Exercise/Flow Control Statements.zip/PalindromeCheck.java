import java.util.*;
class PalindromeCheck{
	public static void main(String ar[]){
		int i,r,n,s=0;
		Scanner sc=new Scanner(System.in);
		i= sc.nextInt();
		n=i;
		while(i>0){
			r=i%10;
			s=s*10+r;
			i=i/10;
		}
		if(n==s)
			System.out.print(n+" is a Palindrome");
		else
			System.out.print(n+" is not a Palindrome");
	}
}