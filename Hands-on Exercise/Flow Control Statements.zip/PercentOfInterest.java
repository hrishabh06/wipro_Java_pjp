import java.util.*;
class PercentOfInterest{
	public static void main(String ar[]){
		String s;
		int age;
		Scanner sc = new Scanner(System.in);
		age = sc.nextInt();
		Scanner b = new Scanner(System.in);
		s = b.nextLine();
		
		if (s.equals("Female") && (age>=1 && age<=58)) 
			System.out.print(" Percentage of Interest is 8.2% "); 
		else if (s.equals("Female") && (age>=59 && age<=100)) 
			System.out.print(" Percentage of Interest is 9.2% "); 
		else if (s.equals("Male") && (age>=1 && age<=58)) 
			System.out.print(" Percentage of Interest is 8.4% "); 
		else if (s.equals("Male") && (age>=59 && age<=100)) 
			System.out.print(" Percentage of Interest is 10.5% "); 
		
	}
}