import java.util.*;
class PositiveOrNegative{
	public static void main(String ar[]){
		int i;
		Scanner sc=new Scanner(System.in);
		i=sc.nextInt();
		if(i>0)
			System.out.println(i + " is a Positive Integer");
		else if(i<0)
			System.out.println(i + " is a Negative Integer");
		else
			System.out.println(i + " is equal to zero");
	}
}