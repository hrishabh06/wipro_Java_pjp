import java.util.*;
class PrintPrime{
	public static void main(String ar[]){
		int i,j,m,k,flag;
		Scanner sc=new Scanner(System.in);
		i= sc.nextInt();
		k= sc.nextInt();
		for(m=i;m<k;m++){
			flag=0;
			for(j=2;j<m/2;j++){
				if(m%j==0)
						flag=1;
			}
			if(flag==0)
				System.out.println( m + " is a prime number");
			
		}
	}
}