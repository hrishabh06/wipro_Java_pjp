import java.util.*;
class ReversePrint{
	public static void main(String ar[]){
		int i,r,s=0;
		Scanner sc=new Scanner(System.in);
		i= sc.nextInt();
		while(i>0){
			r=i%10;
			s=s*10+r;
			i=i/10;
		}
		System.out.print(s);
	}
}