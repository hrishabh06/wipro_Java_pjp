class Animal{
	void eat(){
		System.out.println("Animal Class Eat()");
	}
	void sleep(){
		System.out.println("Animal Class Sleep()");
	}
}

class Bird extends Animal{
	void eat(){
		System.out.println("Bird Class Eat()");
	}
	void sleep(){
		System.out.println("Bird Class Sleep()");
	}
	void fly(){
		System.out.println("Bird Class Fly()");
	}
}

public class Example1{
	public static void main(String args[]){
		Animal a=new Animal();
		a.eat();
		a.sleep();
		Bird b=new Bird();
		b.eat();
		b.sleep();
		b.fly();
	}
}