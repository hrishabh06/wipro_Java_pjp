class Person{
	String name,dob;
	public Person(String name, String dob){
		this.name=name;
		this.dob=dob;
	}
	public void show(){
		System.out.println("Person Detail : ");
		System.out.println("\tName: "+name);
		System.out.println("\tDOB : "+dob);
		
	}
}

class Teacher extends Person{
	String sub;
	double salary;
	public Teacher(String name, String dob,String sub, double salary){
		super(name,dob);
		this.sub=sub;
		this.salary=salary;
	}
	public void show(){
		System.out.println("Teacher Detail : ");
		System.out.println("\tName: "+name);
		System.out.println("\tDOB : "+dob);
		System.out.println("\tSub : "+sub);
		System.out.println("\tSalary : "+salary);
	}
}

class Student extends Person{
	int studentId;
	public Student(String name,String dob,int studentId){
		super(name,dob);
		this.studentId=studentId;
	}
	public void show(){
		System.out.println("Student Detail : ");
		System.out.println("\tName: "+name);
		System.out.println("\tDOB : "+dob);
		System.out.println("\tStudent ID : "+studentId);
	}
}

class CollegeStudent extends Student{
	String clgName,year;
	public CollegeStudent(String name,String dob,int studentId, String clgName, String year){
		super(name,dob,studentId);
		this.clgName=clgName;
		this.year=year;
	}
	public void show(){
		System.out.println("College Student Detail : ");
		System.out.println("\tName: "+name); 
		System.out.println("\tDOB : "+dob);
		System.out.println("\tStudent ID : "+studentId);
		System.out.println("\tCollege Name : "+clgName);
		System.out.println("\tYear : "+year);
	}
}

public class Example3{
	public static void main(String args[]){
		Person p=new Person("Ram","03/07/1998");
		p.show();
		Teacher t=new Teacher("Ram","03/07/1998","Chemistry",35000.00);
		t.show();
		Student s=new Student("Rahul","02/02/2010", 1);
		s.show();
		CollegeStudent cs=new CollegeStudent("Rahul","02/02/2010", 1,"Academy Of Technology", "1st");
		cs.show();	
	}
}