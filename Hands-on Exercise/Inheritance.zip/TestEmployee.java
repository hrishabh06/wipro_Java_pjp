class Person{
	String name;
	Person(){}
	Person(String name){
		this.name=name;
	}
	void setName(String name){
		this.name=name;
	}
	String getName(){
		return this.name;
	}
}

class Employee extends Person{
	double annualSalary;
	String startYear, nationalInsuranceNo;
	Employee(){}
	Employee(String startYear, String nationalInsuranceNo, double annualSalary){
		this.startYear=startYear;
		this.nationalInsuranceNo=nationalInsuranceNo;
		this.annualSalary=annualSalary;
	}
	
	void setStartYear(String startYear){
		this.startYear=startYear;
	}
	
	String getStartYear(){
		return this.startYear;
	}
	
	void setNationalInsuranceNo(String nationalInsuranceNo){
		this.nationalInsuranceNo=nationalInsuranceNo;
	}
	
	String getNationalInsuranceNo(){
		return this.nationalInsuranceNo;
	}
	
	void setAnnualSalary(double annualSalary){
		this.annualSalary=annualSalary;
	}
	
	double getAnnualSalary(){
		return this.annualSalary;
	}
}

public class TestEmployee{
	public static void main(String args[]){
		Person p=new Person("Ram");
		System.out.println("Person Name : " + p.getName());
		Employee e=new Employee("09 August 2010", "IN209", 25000.00);
		System.out.println("Employee Starting Year : " + e.getStartYear());
		System.out.println("Employee Insurance Number : " + e.getNationalInsuranceNo());
		System.out.println("Employee Annual Salary : " + e.getAnnualSalary());
	}
}