package com.w3epic.wiprotraining.assignment1;

public class MyUnit {

	public String stringConcat(String a, String b) {
		return a + b;
	}

}
