class Example{
    public static void main(String args[]){
        String s = "Technologies";
        System.out.println(args[0] + " " + s +" " + args[1]);
    }
}