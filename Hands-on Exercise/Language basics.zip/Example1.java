class Example1{
    public static void main(String args[]){
        String s = "Welcome";
        System.out.println( s +" " + args[0]);
    }
}