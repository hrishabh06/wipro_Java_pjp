import java.util.*;  
class JavaExampleMonths{  
	public static void main(String args[]){  
	ArrayList<String> alist=new ArrayList<String>();  
      	alist.add("January");
      	alist.add("February");
      	alist.add("March");
     	alist.add("April");
      	alist.add("May");
      	alist.add("June");
	alist.add("July");
      	alist.add("August");
      	alist.add("September");
     	alist.add("October");
      	alist.add("November");
      	alist.add("December");
  
      System.out.println(alist);
   }  
}