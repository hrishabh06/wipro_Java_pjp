import java.util.*; 
public class MonthUsingLinkedList{ 
    	public static void main(String args[]){
		LinkedList<String> object = new LinkedList<String>(); 
          	object.add("January"); 
        	object.add("February");
		object.add("March"); 
        	object.add("April");
		object.add("May"); 
        	object.add("June");
		object.add("July"); 
        	object.add("August");
		object.add("September"); 
        	object.add("October");
		object.add("November"); 
        	object.add("December"); 
        	
        	System.out.println("Linked list : " + object);
	}
} 