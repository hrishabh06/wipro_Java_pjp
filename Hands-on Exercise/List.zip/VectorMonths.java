import java.util.*; 
class VectorMonths{ 
	public static void main(String[] arg) 
    	{ 
        	Vector v = new Vector(); 
	 
        	v.add("January"); 
        	v.add("February"); 
        	v.add("March"); 
        	v.add("April"); 
		v.add("May"); 
        	v.add("June"); 
		v.add("July"); 
        	v.add("August"); 
		v.add("September"); 
        	v.add("October"); 
		v.add("November"); 
        	v.add("December"); 
  
        	System.out.println("Vector is " + v); 
    } 
}