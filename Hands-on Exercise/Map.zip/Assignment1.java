package com.w3epic.wiprotraining.assignment1;
import java.util.HashMap;

class countryMap{
	void saveCountryCapital(String a,string b){
		HashMap<String, String> M2 = new HashMap<>();
		M2.put(a,b);
	}

	String getCapital(String a){
		HashMap<String, String> M2 = new HashMap<>();
		return(M2.get(a));
	}

	String getCapital(String b){
		HashMap<String, String> M2 = new HashMap<>();
		return(M2.hasValue(b));
	}
}

public class Assignment1{
	public static void main(String[] args){
		CountryMap countryMap = new CountryMap();

		countryMap.saveCountryCapital("India", "Delhi");
		countryMap.saveCountryCapital("Japan", "Tokyo");
		countryMap.saveCountryCapital("USA", "Washington, D.C.");
		
		System.out.println(countryMap.getCapital("India"));
		System.out.println(countryMap.getCountry("Tokyo"));
		System.out.println(countryMap.toArrayList());
		
		HashMap<String, String> M2 = countryMap.swapKyeValue();
		System.out.println(M2);
	}
}
