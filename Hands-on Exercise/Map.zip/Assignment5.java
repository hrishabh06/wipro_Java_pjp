import java.util.HashMap;

public class Assignment5{
	public static void main(String[] args){
		 TreeMap<String, String> treemap = new TreeMap<String, String>();

		void saveCountryCapital(String a,string b){
			treemap.put(a,b);
		}

		String getCapital(String a){
			return(treemap.get(a));	
		}

		String getCapital(String b){
			return(treemap.hasValue(b));
		}
		
		saveCountryCapital("India", "Delhi");
		saveCountryCapital("Japan", "Tokyo");
		saveCountryCapital("USA", "Washington, D.C.");
		
		System.out.println(getCapital("India"));
		System.out.println(getCountry("Tokyo"));
		System.out.println(treemap);
	}
}
