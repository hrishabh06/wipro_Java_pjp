import java.util.HashMap;

public class Assignment6{
	public static void main(String[] args){
		Hashtable<String, String> h = new HashTable<String, String>();

		void saveCountryCapital(String a,string b){
			h.put(a,b);
		}

		String getCapital(String a){
			return(h.get(a));	
		}

		String getCapital(String b){
			return(h.getKey(b));
		}
		
		saveCountryCapital("India", "Delhi");
		saveCountryCapital("Japan", "Tokyo");
		saveCountryCapital("USA", "Washington, D.C.");
		
		System.out.println(getCapital("India"));
		System.out.println(getCountry("Tokyo"));
		System.out.println(h);
	}
}
