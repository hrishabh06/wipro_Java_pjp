import java.util.*;
class fruit{
	String name, taste, size ;
	public void eat( ){
		Scanner sc = new Scanner(System. in );
		System.out.println("enter the name of the fruit ");
		name = sc.nextLine( ) ;
		System.out.println(" please provide the taste of the fruit ");
		taste = sc.nextLine( ) ;
		System.out.println(" Name of the fruit is: " + name);
		System.out.println(" Taste of the fruit is: " + taste);
	}
}
class apple extends fruit{
	public void eat( ){
		System.out.println(" Name of the fruit is Apple ");
		System.out.println(" Taste of the fruit is sweet ");
	}
}
class orange extends fruit{
	public void eat( ){
		System.out.println(" Name of the fruit is Orange ");
		System.out.println(" Taste of the fruit is sour ");
	}
}
public class Example1{
	public static void main( String args[] ){
		apple A = new apple( );
		A.eat( );
		orange O = new orange( );
		O.eat( );
	}
}
