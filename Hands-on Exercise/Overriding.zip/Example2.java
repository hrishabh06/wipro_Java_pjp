import java.util.*;
class Shape{
	public void draw( ){
		System.out.println(" Draw the Shape ");
	}
	public void Erase(){
		System.out.println(" Erase the Shape ");
	}
}
class Circle extends Shape{
	public void draw( ){
		System.out.println(" Drawing Circle ");
	}
	public void Erase(){
		System.out.println(" Erasing Circle ");
	}
}
class Triangle extends Shape{
	public void draw( ){
		System.out.println(" Drawing Triangle ");
	}
	public void Erase(){
		System.out.println(" Erasing Triangle ");
	}
}
class Square extends Shape{
	public void draw( ){
		System.out.println(" Drawing Square ");
	}
	public void Erase(){
		System.out.println(" Erasing Square ");
	}
}
public class Example2{
	public static void main( String args[] ){
		Shape c=new Circle();
		c.draw();
		c.Erase();
		Shape t= new Triangle();
		t.draw();
		t.Erase();
		Shape s=new Square();
		s.draw();
		s.Erase();
	}
}