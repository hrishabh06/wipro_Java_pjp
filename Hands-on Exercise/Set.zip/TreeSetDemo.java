import java.util.TreeSet;
import java.util.Iterator;
public class TreeSetDemo{
	public static void main(String[] args){
		TreeSet<String> t_set = new TreeSet<String>();
		t_set.add("Red");
		t_set.add("Green");
		t_set.add("Black");
		t_set.add("Pink");
		t_set.add("orange");

		Set<Integer> reverseSet = t_set.descendingSet();
		Iterator<Integer> itr = reverseSet.iterator();
		System.out.println("Reverse set contains: ");
		while(itr.hasNext()){
			System.out.println( itr.next());
		}

		boolean result = t_set.contains("Green");
		System.out.println( result );
	}
}