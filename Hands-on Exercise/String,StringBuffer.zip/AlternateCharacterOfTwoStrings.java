import java.util.*;
class AlternateCharacterOfTwoStrings{
	public static void main(String args[]){
		StringBuilder r=new StringBuilder();
		int i,m,n,j=0;
		String a,b;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		b=sc.nextLine();
		m=a.length();
		n=b.length();
		for(i=0;i<m||i<n;i++){
			if(i<m)
				r.append(a.charAt(i));
			if(i<n)
				r.append(b.charAt(i));			
		}
		System.out.println(r);
	}
}