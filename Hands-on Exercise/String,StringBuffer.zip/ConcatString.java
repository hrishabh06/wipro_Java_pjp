import java.util.*;
class ConcatString{
	public static void main(String args[]){
		String a,b;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		b=sc.nextLine();
		int i,j=0,m,n;
		m=a.length();
		n=b.length();
		char[] p=new char[m];
		char[] q=new char[n];
		
		for(i=0;i<m;i++){
			p[i]=a.charAt(i);
		}
		for(i=0;i<n;i++){
			q[i]=b.charAt(i);
		}
		if(p[m-1]==q[n-1]){
			char[] r=new char[m+n-1];
			for(i=0;i<m;i++){
				r[j++]=p[i];
			}
			for(i=2;i<n;i++){
				r[j++]=q[i];
			}
			System.out.println(r);	
		}
		else{
			System.out.println(a.concat(b));
		}
		
	}
}