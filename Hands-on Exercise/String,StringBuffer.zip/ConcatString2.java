import java.util.*;
class ConcatString2{
	public static void main(String args[]){
		String a,b;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		b=sc.nextLine();
		int i,j=0,m,n;
		m=a.length();
		n=b.length();
	
		if(n>m){
			System.out.println(a.concat(b.concat(a)));
		}
		else{
			System.out.println(b.concat(a.concat(b)));
		}
		
	}
}