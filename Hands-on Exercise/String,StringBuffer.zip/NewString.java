import java.util.*;
class NewString{
	public static void main(String args[]){
		String a;
		int i,m;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		m=a.length();
		char[] p=new char[2];
		for(i=0;i<2;i++){
			p[i]=a.charAt(i);
		}
		for(i=0;i<m;i++)
			System.out.print(p);
	}
}