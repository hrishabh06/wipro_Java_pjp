import java.util.*;
class NewString2{
	public static void main(String args[]){
		String a;
		int i,m;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		m=a.length();
		char[] p=new char[m/2];
		if(m%2==0){
			for(i=0;i<m/2;i++){
				p[i]=a.charAt(i);
			}
			System.out.print(p);
		}
		else{
			System.out.println("Null");
		}
	}
}