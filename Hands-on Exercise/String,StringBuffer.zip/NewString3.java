import java.util.*;
class NewString3{
	public static void main(String args[]){
		String a;
		int i,m,j=0;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		m=a.length();
		char[] p=new char[m];
		for(i=1;i<m-1;i++){
				p[j++]=a.charAt(i);
		}
		System.out.print(p);
	}
}