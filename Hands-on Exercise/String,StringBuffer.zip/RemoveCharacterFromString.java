import java.util.*;
class RemoveCharacterFromString{
	public static void main(String args[]){
		String a;
		int i,m,j=0;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		m=a.length();
		char[] p=new char[m];
		char[] q=new char[m];
		for(i=0;i<m;i++){
			p[i]=a.charAt(i);
		}
		for(i=0;i<m;i++){
			if(p[i]=='*'){
				j=i;
				break;
			}
		}
		int c=j-1,d=j+1;
		j=0;
		for(i=0;i<c;i++){
			q[j++]=p[i];
		}
		for(i=d+1;i<m;i++){
			q[j++]=p[i];
		}
		System.out.println(q);
	}
}