import java.util.*;
class RemoveFirstAndLastCharacter{
	public static void main(String args[]){
		String a;
		int i,m,j=0;
		Scanner sc=new Scanner(System.in);
		a=sc.nextLine();
		m=a.length();
		char[] p=new char[m];
		char[] q=new char[m];
		for(i=0;i<m;i++){
			p[i]=a.charAt(i);
		}
		if(p[0]=='x' && p[m-1]=='x'){
			for(i=1;i<m-1;i++)
				q[j++]=p[i];
			System.out.print(q);
		}
		else
			System.out.print(p);
	}
}