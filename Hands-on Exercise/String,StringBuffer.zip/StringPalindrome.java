import java.util.*;
import java.io.*;
class StringPalindrome{
	public static void main(String[] ar){
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String a="";
		int flag=0,i,n=s.length();
		for(i=n-1;i>=0;i--){
			a=a+s.charAt(i);
		}
		if(s.equalsIgnoreCase(a)){
			System.out.println(s + " is a palindrome");
		}
		else
			System.out.println(s + " is not a palindrome");
	}
}