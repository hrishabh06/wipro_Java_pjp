import java.util.*;
import java.io.*;
class DecimalBinaryExample{
	public static void main(String a[]){
		DecimalBinaryExample obj = new DecimalBinaryExample();
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		System.out.println(Integer.toBinaryString(num));
		
		String numberAsString = String.format ("%08d",Integer.toBinaryString(num));
		System.out.println(numberAsString);
	}
}

