import java.io.*;
class Test{
	int x,y;
	Test(){
		x=10;
		y=20;
	}
}
public class MainTest{
	public static void main(String[] ar){
		Test ob=new Test();
		System.out.println(ob.x+"  "+ob.y);
		Test ob1=ob;
		ob1.x=100;
		System.out.println(ob.x+"  "+ob.y);
		System.out.println(ob1.x+"  "+ob1.y);
	}
}